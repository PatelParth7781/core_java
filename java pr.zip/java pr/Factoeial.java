/*Write a Java Program to calculate factorial of Given Number */

import java.util.Scanner;
public class Factorial {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number:");
		int num = scanner.nextInt();
		int factorial = 1;
		
		for(int i=1;i<=num;i++) {
			factorial = factorial * i;
		}
		
		System.out.println("Factorial of " + num + " is: " + factorial);
	}
	    /*Enter a number:
		  3
		  Factorial of 3 is: 6*/

}
