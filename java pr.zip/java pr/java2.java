import java.util.Scanner;
public class java2 {
    public static void main(String[] args)
    {
        System.out.println("enter no");
        Scanner sc = new Scanner(System.in);

        int i;
        int n = sc.nextInt();
        for(i=0;i<n;i++)
        {
            if(i%5==0 && i%7==0)
            System.out.println("Num: "+i);
        }
    }
}
