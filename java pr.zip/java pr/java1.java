import java.util.Scanner;
public class java1
{
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		int i,sum=0,avg_value;
		System.out.println("Enter n:");

		int n= scanner.nextInt();
		
		for(i=0;i<n;i++)
{
		int a = scanner.nextInt();
		sum+=a;

}		
avg_value = sum/n;
System.out.println("sum is: "+sum);
System.out.println("Avg is:"+avg_value);
}
}
		
		